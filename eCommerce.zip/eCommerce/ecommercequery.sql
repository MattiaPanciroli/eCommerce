CREATE DATABASE ecommerce;
USE ecommerce;
  	
CREATE TABLE indirizzi(
	Id INT NOT NULL,
   via VARCHAR(50) NOT NULL,
   citta VARCHAR(50) NOT NULL,
   numero INT NOT NULL,
   codicePostale INT(5) NOT NULL,
   PRIMARY KEY (Id)
);

CREATE TABLE ruoli(
	Id INT PRIMARY KEY,
	ruolo VARCHAR(30)
);

CREATE TABLE users(
	Id INT PRIMARY KEY,
   nome VARCHAR(50) NOT NULL,
   cognome VARCHAR(50) NOT NULL,
   Id_indirizzo INT NOT NULL,
   username VARCHAR(50) NOT NULL,
   password_utente VARCHAR(60) NOT NULL,
   ruolo INT NOT NULL,
   FOREIGN KEY (Id_indirizzo) REFERENCES indirizzi(Id),
   FOREIGN KEY (ruolo) REFERENCES ruoli(Id)
);

CREATE TABLE categorie(
	Id INT NOT NULL,
   nome VARCHAR(50) NOT NULL,
   immagine VARCHAR(50) NOT NULL,
   PRIMARY KEY (Id)
);

CREATE TABLE accessori(
	Id INT NOT NULL,
   nome VARCHAR(50) NOT NULL,
   costo DECIMAL(10,2) NOT NULL,
   PRIMARY KEY (Id)
);

CREATE TABLE prodotti(
	Id INT NOT NULL,
	nome VARCHAR(50) NOT NULL,
	immagine VARCHAR(50) NOT NULL,
   Id_accessorio INT NOT NULL,
   Id_categoria INT NOT NULL,
   costo DECIMAL(10,2) NOT NULL,
   PRIMARY KEY (Id),
   FOREIGN KEY (Id_accessorio) REFERENCES accessori(Id),
   FOREIGN KEY (Id_categoria) REFERENCES categorie(Id)
);

CREATE TABLE carrello(
	Id INT NOT NULL,
	Id_user INT NOT NULL,
   PRIMARY KEY (Id),
   FOREIGN KEY (Id_user) REFERENCES users(Id)
);

CREATE TABLE carrello_prodotti(
	Id_carrello INT NOT NULL,
   Id_prodotto int NOT NULL,
   FOREIGN KEY (Id_carrello) REFERENCES carrello(Id),
   FOREIGN KEY (Id_prodotto) REFERENCES prodotti(Id)
);

CREATE TABLE ordine(
	Id INT NOT NULL,
   Id_user INT NOT NULL,
   Id_prodotto INT NOT NULL,
   Id_accessorio INT NOT NULL,
   stato VARCHAR(50) NOT NULL,
   `data` DATE NOT NULL,
   PRIMARY KEY (Id),
   FOREIGN KEY (Id_user) REFERENCES users(Id),
   FOREIGN KEY (Id_prodotto) REFERENCES prodotti(Id),
   FOREIGN KEY (Id_accessorio) REFERENCES accessori(Id)
);

CREATE TABLE accessori_prodotti(
	Id_prodotto INT NOT NULL,
   Id_accessorio INT NOT NULL,
   FOREIGN KEY (Id_prodotto) REFERENCES prodotti(Id),
   FOREIGN KEY (Id_accessorio) REFERENCES accessori(Id)
);


INSERT INTO categorie (Id, nome, immagine)
VALUES (1, 'Salotto', 'salotto.jpeg'),
(2, 'Cucina', 'cucina.jpeg'),
(3, 'Ufficio', 'ufficio.jpeg'),
(4, 'Camera da Letto', 'camera.jpeg'),
(5, 'Giardino', 'giardino.jpeg');









