<?php 
    include "connessione.php";
    session_start();
    $conn = new mysqli($hostname, $username, $password, $dbname);

    // Verifica la connessione
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    if (isset($_POST['IdProdotto']) && isset($_SESSION['username'])) {
        $id = $_POST['IdProdotto'];
        
        $sql = "INSERT INTO carrello(Id_prodotto, Id_user) VALUES (". $_POST['IdProdotto'] .",". $_SESSION['Id'] .");";
        $ris = mysqli_query($conn, $sql);

        $query = "SELECT * FROM users WHERE users.username = '". $_SESSION['username']."';";
        $risultato = mysqli_query($conn, $query);

        if ($risultato === false) {
            die("Errore nell'esecuzione della query: " . mysqli_error($conn));
        }

        $user = mysqli_fetch_assoc($risultato);
        header('Location: carrello.php');
        exit();
    }
    else {
        header('Location: ./login.php');
        exit();
    }
?>