<?php
    session_start();

    include "connessione.php";      
    $conn = new mysqli($hostname, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    if (isset($_POST['username']) && isset($_POST['password'])) {
        // Pulizia delle variabili di input
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        // Esecuzione di una query preparata per evitare SQL injection
        /*
        $sql = "SELECT * FROM users WHERE username = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        */
        $query = "SELECT * FROM users WHERE username = '$username'";
        $ris = mysqli_query($conn, $query);

        if ($ris === false) {
            die("Errore nell'esecuzione della query: " . mysqli_error($conn));
        }

        $user = mysqli_fetch_assoc($ris);
        // echo $user['password'];

        if ($user !== null) {
            
            // Verifica delle password utilizzando la funzione password_verify  //if (password_verify(trim($_POST['password']), trim($user['password'])))
            if ($password === $user['password_utente']) {
                // Credenziali corrette, impostare variabili di sessione
                $_SESSION['username'] = $username;
                $_SESSION['account_type'] = $user['account_type'];
                $_SESSION['Id'] = $user['Id'];
                //indirizzo alla pagina che mi interessa.
                header('Location: ../index.php?ciao');
                exit();
            } else {
                // password  non corretta, reindirizza alla pagina di login
                header('Location: ../index.php?error=1');
                exit();
            }
        } else {
            // Utente non trovato, reindirizza alla pagina di login
            header('Location: ../index.php?error=2');
            exit();
        }
    } else {
        // Se i campi non sono stati inviati, reindirizza alla pagina di login. 
        // In realtà il Form di Login richiede l'obbligo di inserire entrambi i campi quindi questa parte potrebbe essere omessa
        header('Location: ../index.php?hello');
        exit();
    }

    // Chiudi la connessione al database
    $conn->close();
?>