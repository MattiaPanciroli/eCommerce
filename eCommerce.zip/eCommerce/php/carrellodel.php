<?php 
    include "connessione.php";
    session_start();
    $conn = new mysqli($hostname, $username, $password, $dbname);

    // Verifica la connessione
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    if (isset($_POST['IdCarrello'])) {
        $id = $_POST['IdCarrello'];
        
        $sql = "DELETE FROM carrello WHERE carrello.Id = $id ";
        $ris = mysqli_query($conn, $sql);
        
        header('Location: carrello.php');
        exit();
    }
?>