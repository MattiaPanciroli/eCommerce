<?php 
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ecommerce";
?>