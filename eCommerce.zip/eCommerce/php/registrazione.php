<?php
    include "connessione.php";
    // Crea la connessione
    $conn = new mysqli($hostname, $username, $password, $dbname);

    // Verifica la connessione
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }
    $nome = $_POST["nome"];
    $cognome = $_POST["cognome"];
    $via = $_POST["via"];
    $citta = $_POST["citta"];
    $numero = $_POST["numero"];
    $codicePostale = $_POST["codicePostale"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $account = "user";
    //$username = "carlo.cafferata@itis.pr.it";
    //$password = "Password";
    //$account = "admin";
    // Genera l'hash della password
    //$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO indirizzi (via, citta, numero, codicePostale) VALUES ($via, $citta, $numero, $codicePostale)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $hashedPassword);

    // Esegui la query INSERT INTO per inserire i dati nel database
    $sql = "INSERT INTO users (username, password_utente, ruolo) VALUES (?, ?, '$account')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $hashedPassword);

    if ($stmt->execute()) {
        echo "Utente registrato con successo!";
    } else {
        echo "Query failed: " . $stmt->error;
    }

    // Chiudi la connessione
    $stmt->close();
    $conn->close();

    header('Location: ../index.html');